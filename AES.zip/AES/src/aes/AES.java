package aes;


public class AES {

    public static void main(String[] args) {
           new Vista().setVisible(true);     
    }
}
