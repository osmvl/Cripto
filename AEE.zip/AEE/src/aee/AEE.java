package aee;

public class AEE {

    public static void main(String[] args) {
        new Vista().setVisible(true);
    }

}
