package p0c;

public class P0C {

    public static void main(String[] args) {
        new Vista().setVisible(true);
    }
    
}
